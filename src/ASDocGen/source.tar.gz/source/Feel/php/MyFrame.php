&nbsp;<? local_doc_url("visualdoc.php","Index","visualselect",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("visualdoc.php","Topics","index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("visualdoc.php","Glossary","Glossary",$srcunset,$subunset) ?>
  &nbsp; <a href="visualdoc.php?show=faq">F.A.Q.</a>
 &nbsp; <a href="visualdoc.php?show=authors">Copyright</a>
<hr>
&nbsp;<b>Overview</b>
<hr>






<LI><A NAME="options"></A><B>CONFIGURATION OPTIONS :</B><P>
<DL>













































































</DL></P></LI>
